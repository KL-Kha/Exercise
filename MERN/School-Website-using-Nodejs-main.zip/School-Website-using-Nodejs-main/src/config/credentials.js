module.exports = {
    "cookieSecret": "kghkasfcgnasuyg6526as",
    "mongo": {
        "connectionString": "mongodb+srv://vinhtieng:vinhtieng@cluster0.ugswm.mongodb.net/AdvancedWeb2122?retryWrites=true&w=majority"
    },
    "google": {
        "clientID": "59826905681-qoelvu7i69m06fhbut2g70fkgehoime6.apps.googleusercontent.com",
        "clientSecret": "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",
        "callbackURL": "https://advanced-web-tdtu-2021-2022.herokuapp.com/google/callback"
    },
    "cloudinary": {
        "cloud_name": "nguyenvinhtieng",
        "api_key": "759141759622245",
        "api_secret": "yEjkljPOCBHmxA2P2v7kLUdX0Ho"
    }
}

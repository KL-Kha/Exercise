# School-Website-using-Nodejs

Environment Dev: Nodejs[handlebars] + MongoDB[compass]

Some function:
+ Admin: create, edit, delete department...
+ Department: Create, edit, delete notification...
+ Student(user): Create new post, change password, view notification, view another post, view personal...

Make sure your device installed Nodejs + MongoDB
Step by step:
+ Run mongoDB compass and login server
+ Open project folder and init terminal
+ Run: "$npm intall" to intall package as nodes_module folder
+ Run: "$npm start" to start project
